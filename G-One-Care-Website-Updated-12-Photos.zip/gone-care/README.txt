G.ONE CARE - WEBSITE PROTOTYPE
Open index.html in a web browser. Keep the assets folder beside it.

DEMO ONLY: No bookings, patient data storage, payment processing, or consultations are active.
Form is entirely client-side and does not send or save data. Do not enter real patient details.

Before launch:
1. Verify Dr. Imran's valid medical registration and display registration number.
2. Set up compliant secure patient intake, records, privacy policy, terms and consent.
3. Connect server-side booking, calendar, payment gateway and payment webhook verification.
4. Integrate secure video service, receipts, cancellation/refund rules.
5. Add real consultation hours and clinician availability.
6. Review professional advertising/telemedicine compliance and accessibility.
7. Label AI imagery clearly and do not imply staged procedures are real patient encounters.

Hosting: Upload index.html and assets/ to a static hosting provider (Netlify, Vercel, etc.) for a demo only.
